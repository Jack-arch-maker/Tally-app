import crypto from "node:crypto";
import { db } from "./db.js";
import { PRICES, config } from "./config.js";
import { HttpError } from "./util.js";

export const billingEnabled = () => !!config.stripe.secretKey;

/** Stripe's API wants form-encoded bodies with bracketed nested keys. */
function encodeForm(obj, prefix = "", out = []) {
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null) continue;
    const key = prefix ? `${prefix}[${k}]` : k;
    if (Array.isArray(v)) v.forEach((item, i) => (typeof item === "object" ? encodeForm(item, `${key}[${i}]`, out) : out.push(`${encodeURIComponent(`${key}[${i}]`)}=${encodeURIComponent(item)}`)));
    else if (typeof v === "object") encodeForm(v, key, out);
    else out.push(`${encodeURIComponent(key)}=${encodeURIComponent(v)}`);
  }
  return out;
}

async function stripe(method, path, body) {
  if (!billingEnabled()) throw new HttpError(503, "Billing isn't switched on yet.");
  const qs = method === "GET" && body ? "?" + encodeForm(body).join("&") : "";
  let res;
  try {
    res = await fetch(`${config.stripe.baseUrl}/v1${path}${qs}`, {
      method,
      headers: {
        authorization: `Bearer ${config.stripe.secretKey}`,
        ...(method !== "GET" ? { "content-type": "application/x-www-form-urlencoded" } : {}),
      },
      body: method !== "GET" && body ? encodeForm(body).join("&") : undefined,
      signal: AbortSignal.timeout(20_000),
    });
  } catch (e) {
    console.error("Stripe request failed:", e.message);
    throw new HttpError(502, "Couldn't reach the payment provider. Please try again.");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.error("Stripe error", res.status, JSON.stringify(data).slice(0, 400));
    throw new HttpError(502, data?.error?.message || "The payment provider returned an error.");
  }
  return data;
}

/** Only allow redirecting back to our own site. */
function safeReturnUrl(req, returnUrl) {
  const fallback = config.publicUrl || `${req.protocol}://${req.get("host")}/`;
  try {
    const u = new URL(returnUrl);
    const allowed = new URL(config.publicUrl || `${req.protocol}://${req.get("host")}`);
    return u.origin === allowed.origin ? u.toString() : fallback;
  } catch {
    return fallback;
  }
}

async function ensureCustomer(user) {
  if (user.stripe_customer_id) return user.stripe_customer_id;
  const c = await stripe("POST", "/customers", { email: user.email, name: user.name, metadata: { tally_user_id: user.id } });
  db.prepare("UPDATE users SET stripe_customer_id=? WHERE id=?").run(c.id, user.id);
  return c.id;
}

export async function createCheckout(req, user, interval) {
  interval = interval === "month" ? "month" : "year";
  const customer = await ensureCustomer(user);
  const priceId = interval === "month" ? config.stripe.priceMonth : config.stripe.priceYear;
  const line = priceId
    ? { price: priceId, quantity: 1 }
    : {
        quantity: 1,
        price_data: {
          currency: "usd",
          unit_amount: Math.round(PRICES[interval] * 100),
          recurring: { interval },
          product_data: { name: "Tally Pro", description: "Penny, bank import, unlimited buckets and savings goals" },
        },
      };
  const back = safeReturnUrl(req, req.body?.returnUrl);
  const session = await stripe("POST", "/checkout/sessions", {
    mode: "subscription",
    customer,
    client_reference_id: String(user.id),
    line_items: [line],
    success_url: back,
    cancel_url: back,
    allow_promotion_codes: "true",
    subscription_data: { metadata: { tally_user_id: user.id } },
  });
  return { url: session.url };
}

export async function createPortal(req, user) {
  if (!user.stripe_customer_id) throw new HttpError(400, "There's no subscription to manage yet.");
  const s = await stripe("POST", "/billing_portal/sessions", {
    customer: user.stripe_customer_id,
    return_url: safeReturnUrl(req, req.body?.returnUrl),
  });
  return { url: s.url };
}

/* ---------------------- applying subscription state ---------------------- */
const ACTIVE = new Set(["active", "trialing", "past_due"]);

function applySubscription(userId, sub) {
  const active = sub && ACTIVE.has(sub.status);
  if (active) {
    const item = sub.items?.data?.[0];
    const interval = item?.price?.recurring?.interval || item?.plan?.interval || null;
    const end = item?.current_period_end ?? sub.current_period_end;
    db.prepare(
      "UPDATE users SET plan='pro', plan_source='stripe', plan_interval=?, plan_renews_at=? WHERE id=?"
    ).run(interval === "month" ? "month" : interval === "year" ? "year" : null, end ? new Date(end * 1000).toISOString() : null, userId);
  } else {
    // Never take away a Pro plan that an admin granted by hand.
    db.prepare(
      "UPDATE users SET plan='free', plan_source='none', plan_interval=NULL, plan_renews_at=NULL WHERE id=? AND plan_source='stripe'"
    ).run(userId);
  }
}

/** Ask Stripe for the truth and update the user. Safe to call as often as you like. */
export async function syncPlan(user) {
  if (!billingEnabled() || !user.stripe_customer_id) return;
  const list = await stripe("GET", "/subscriptions", { customer: user.stripe_customer_id, status: "all", limit: 10 });
  const subs = list.data || [];
  const best = subs.find((s) => ACTIVE.has(s.status)) || null;
  applySubscription(user.id, best);
}

/* -------------------------------- webhook -------------------------------- */
export function verifyWebhook(rawBody, header) {
  const secret = config.stripe.webhookSecret;
  if (!secret) throw new HttpError(503, "Webhook secret isn't configured.");
  const parts = Object.fromEntries(
    String(header || "").split(",").map((p) => p.split("=").map((x) => x.trim())).filter((p) => p.length === 2)
  );
  const t = parts.t;
  const sigs = String(header || "").split(",").filter((p) => p.trim().startsWith("v1=")).map((p) => p.trim().slice(3));
  if (!t || !sigs.length) throw new HttpError(400, "Bad signature header.");
  const expected = crypto.createHmac("sha256", secret).update(`${t}.${rawBody}`).digest("hex");
  const ok = sigs.some((s) => s.length === expected.length && crypto.timingSafeEqual(Buffer.from(s), Buffer.from(expected)));
  if (!ok) throw new HttpError(400, "Signature check failed.");
  if (Math.abs(Date.now() / 1000 - Number(t)) > 600) throw new HttpError(400, "Webhook timestamp too old.");
  return JSON.parse(rawBody);
}

export async function handleWebhook(event) {
  const obj = event.data?.object || {};
  const byCustomer = (cid) => db.prepare("SELECT * FROM users WHERE stripe_customer_id=?").get(cid);
  switch (event.type) {
    case "checkout.session.completed": {
      let user = obj.customer ? byCustomer(obj.customer) : null;
      if (!user && obj.client_reference_id) {
        user = db.prepare("SELECT * FROM users WHERE id=?").get(Number(obj.client_reference_id));
        if (user && obj.customer) db.prepare("UPDATE users SET stripe_customer_id=? WHERE id=?").run(obj.customer, user.id);
      }
      if (user) await syncPlan(db.prepare("SELECT * FROM users WHERE id=?").get(user.id));
      break;
    }
    case "customer.subscription.created":
    case "customer.subscription.updated":
    case "customer.subscription.deleted": {
      const user = byCustomer(obj.customer);
      if (user) applySubscription(user.id, event.type.endsWith("deleted") ? null : obj);
      break;
    }
    default:
      break;
  }
}
