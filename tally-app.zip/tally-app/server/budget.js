import { db } from "./db.js";
import { CATEGORIES, FREE_BUCKET_LIMIT, config } from "./config.js";
import { HttpError, cleanText, isValidDate, isoDate, moneyAmount, round2 } from "./util.js";

/* ------------------------------ users ------------------------------ */
export function isAdminEmail(email) {
  return config.adminEmails.includes(String(email).toLowerCase());
}

export function publicUser(row) {
  const admin = isAdminEmail(row.email);
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    isAdmin: admin,
    plan: admin ? "pro" : row.plan,
    planInterval: row.plan === "pro" ? row.plan_interval : null,
    planRenewsAt: row.plan === "pro" ? row.plan_renews_at : null,
  };
}
export const isPro = (userRow) => isAdminEmail(userRow.email) || userRow.plan === "pro";

/* ----------------------------- buckets ----------------------------- */
export const DEFAULT_BUCKETS = [
  { name: "Bills", percent: 50, kind: "spending", goal: null },
  { name: "Savings", percent: 20, kind: "savings", goal: null },
  { name: "Personal", percent: 10, kind: "spending", goal: null },
  { name: "Emergency fund", percent: 10, kind: "savings", goal: null },
];

export function seedDefaultBuckets(userId) {
  const ins = db.prepare(
    "INSERT INTO buckets (user_id,name,percent,kind,goal,starting_balance,color,position) VALUES (?,?,?,?,?,0,?,?)"
  );
  DEFAULT_BUCKETS.forEach((b, i) => ins.run(userId, b.name, b.percent, b.kind, b.goal, String((i % 5) + 1), i));
}

const bucketOut = (b) => ({
  id: b.id,
  name: b.name,
  percent: b.percent,
  kind: b.kind,
  goal: b.goal,
  startingBalance: b.starting_balance,
  color: b.color,
});

export const listBucketRows = (userId) =>
  db.prepare("SELECT * FROM buckets WHERE user_id=? ORDER BY position, id").all(userId);
export const listBuckets = (userId) => listBucketRows(userId).map(bucketOut);

function cleanBucketInput(body, { partial = false } = {}) {
  const out = {};
  if (!partial || body.name !== undefined) {
    const name = cleanText(body.name, 40);
    if (!name) throw new HttpError(400, "Give the bucket a name.");
    out.name = name;
  }
  if (!partial || body.percent !== undefined) {
    const p = Number(body.percent);
    if (!Number.isFinite(p) || p < 0 || p > 100) throw new HttpError(400, "Percent must be between 0 and 100.");
    out.percent = round2(p);
  }
  if (!partial || body.kind !== undefined) {
    if (!["spending", "savings"].includes(body.kind)) throw new HttpError(400, "Kind must be spending or savings.");
    out.kind = body.kind;
  }
  if (body.goal !== undefined) {
    if (body.goal === null || body.goal === "") out.goal = null;
    else {
      const g = Number(body.goal);
      if (!Number.isFinite(g) || g < 0) throw new HttpError(400, "Goal must be zero or more.");
      out.goal = g === 0 ? null : round2(g);
    }
  }
  if (body.startingBalance !== undefined) {
    const s = Number(body.startingBalance) || 0;
    if (!Number.isFinite(s) || Math.abs(s) > 1e9) throw new HttpError(400, "Starting balance isn't valid.");
    out.starting_balance = round2(s);
  }
  if (body.color !== undefined) out.color = String(((parseInt(body.color, 10) || 1) - 1 + 5) % 5 + 1);
  return out;
}

export function createBucket(user, body) {
  const count = db.prepare("SELECT COUNT(*) c FROM buckets WHERE user_id=?").get(user.id).c;
  if (!isPro(user) && count >= FREE_BUCKET_LIMIT)
    throw new HttpError(403, `Free plans include up to ${FREE_BUCKET_LIMIT} buckets. Upgrade to Pro for more.`);
  const b = cleanBucketInput({ kind: "spending", percent: 0, ...body });
  if (!isPro(user)) b.goal = null;
  const pos = db.prepare("SELECT COALESCE(MAX(position),-1)+1 p FROM buckets WHERE user_id=?").get(user.id).p;
  const info = db
    .prepare(
      "INSERT INTO buckets (user_id,name,percent,kind,goal,starting_balance,color,position) VALUES (?,?,?,?,?,?,?,?)"
    )
    .run(user.id, b.name, b.percent, b.kind, b.goal ?? null, b.starting_balance ?? 0, b.color ?? String((count % 5) + 1), pos);
  return bucketOut(db.prepare("SELECT * FROM buckets WHERE id=?").get(info.lastInsertRowid));
}

export function updateBucket(user, id, body) {
  const row = db.prepare("SELECT * FROM buckets WHERE id=? AND user_id=?").get(id, user.id);
  if (!row) throw new HttpError(404, "Bucket not found.");
  const b = cleanBucketInput(body, { partial: true });
  if (!isPro(user)) delete b.goal; // savings goals are a Pro feature
  const keys = Object.keys(b);
  if (keys.length) {
    db.prepare(`UPDATE buckets SET ${keys.map((k) => `${k}=@${k}`).join(",")} WHERE id=@id`).run({ ...b, id });
  }
  return bucketOut(db.prepare("SELECT * FROM buckets WHERE id=?").get(id));
}

export function deleteBucket(user, id) {
  const info = db.prepare("DELETE FROM buckets WHERE id=? AND user_id=?").run(id, user.id);
  if (!info.changes) throw new HttpError(404, "Bucket not found.");
}

/* ------------------------ incomes & expenses ------------------------ */
const incomeOut = (r) => ({
  id: r.id, source: r.source, amount: r.amount, date: r.date, isPaycheck: !!r.is_paycheck,
});
const expenseOut = (r) => ({
  id: r.id, description: r.description, amount: r.amount, category: r.category, date: r.date, bucketId: r.bucket_id,
});

export const listIncomes = (uid) =>
  db.prepare("SELECT * FROM incomes WHERE user_id=? ORDER BY date DESC, id DESC").all(uid).map(incomeOut);
export const listExpenses = (uid) =>
  db.prepare("SELECT * FROM expenses WHERE user_id=? ORDER BY date DESC, id DESC").all(uid).map(expenseOut);

/** Split an amount across buckets by percent. If percents total more than 100 they're scaled down. */
export function computeSplit(amount, buckets) {
  const active = buckets.filter((b) => b.percent > 0);
  const total = active.reduce((s, b) => s + b.percent, 0);
  const scale = total > 100 ? 100 / total : 1;
  let used = 0;
  const parts = active.map((b) => {
    // Floor to whole cents (with a tiny epsilon for float noise) so we never overshoot the paycheck.
    const cents = Math.floor(amount * b.percent * scale + 1e-6) / 100;
    used += cents;
    return { bucketId: b.id, amount: round2(cents) };
  });
  return { parts: parts.filter((p) => p.amount > 0), unassigned: round2(amount - used) };
}

export function addIncome(userId, { source, amount, date, isPaycheck = true }) {
  source = cleanText(source, 80) || "Income";
  amount = moneyAmount(amount);
  date = date || isoDate();
  if (!isValidDate(date)) throw new HttpError(400, "That date doesn't look right.");
  const tx = db.transaction(() => {
    const info = db
      .prepare("INSERT INTO incomes (user_id,source,amount,date,is_paycheck) VALUES (?,?,?,?,?)")
      .run(userId, source, amount, date, isPaycheck ? 1 : 0);
    const id = info.lastInsertRowid;
    let split = { parts: [], unassigned: amount };
    if (isPaycheck) {
      split = computeSplit(amount, listBuckets(userId));
      const ins = db.prepare("INSERT INTO income_splits (income_id,bucket_id,amount) VALUES (?,?,?)");
      for (const p of split.parts) ins.run(id, p.bucketId, p.amount);
    }
    return { id, split };
  });
  const { id, split } = tx();
  return { income: incomeOut(db.prepare("SELECT * FROM incomes WHERE id=?").get(id)), split };
}

export function deleteIncome(userId, id) {
  const info = db.prepare("DELETE FROM incomes WHERE id=? AND user_id=?").run(id, userId);
  if (!info.changes) throw new HttpError(404, "Income not found.");
  db.prepare("DELETE FROM bank_txns WHERE kind='income' AND entry_id=?").run(id);
}

export function addExpense(userId, { description, amount, category, date, bucketId }) {
  description = cleanText(description, 120);
  if (!description) throw new HttpError(400, "Add a short description.");
  amount = moneyAmount(amount);
  category = CATEGORIES.includes(category) ? category : "Other";
  date = date || isoDate();
  if (!isValidDate(date)) throw new HttpError(400, "That date doesn't look right.");
  let bid = null;
  if (bucketId !== null && bucketId !== undefined && bucketId !== "") {
    const b = db.prepare("SELECT id FROM buckets WHERE id=? AND user_id=?").get(Number(bucketId), userId);
    if (!b) throw new HttpError(400, "That bucket doesn't exist.");
    bid = b.id;
  }
  const info = db
    .prepare("INSERT INTO expenses (user_id,description,amount,category,date,bucket_id) VALUES (?,?,?,?,?,?)")
    .run(userId, description, amount, category, date, bid);
  return expenseOut(db.prepare("SELECT * FROM expenses WHERE id=?").get(info.lastInsertRowid));
}

export function deleteExpense(userId, id) {
  const info = db.prepare("DELETE FROM expenses WHERE id=? AND user_id=?").run(id, userId);
  if (!info.changes) throw new HttpError(404, "Expense not found.");
  db.prepare("DELETE FROM bank_txns WHERE kind='expense' AND entry_id=?").run(id);
}

/* ------------------------------ summary ------------------------------ */
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function summary(userId, now = new Date()) {
  const buckets = listBucketRows(userId);
  const allocRows = db
    .prepare(
      `SELECT s.bucket_id id, SUM(s.amount) a FROM income_splits s
       JOIN incomes i ON i.id=s.income_id WHERE i.user_id=? GROUP BY s.bucket_id`
    )
    .all(userId);
  const spentRows = db
    .prepare("SELECT bucket_id id, SUM(amount) a FROM expenses WHERE user_id=? AND bucket_id IS NOT NULL GROUP BY bucket_id")
    .all(userId);
  const alloc = Object.fromEntries(allocRows.map((r) => [r.id, r.a]));
  const spent = Object.fromEntries(spentRows.map((r) => [r.id, r.a]));

  const out = buckets.map((b) => {
    const allocated = round2(alloc[b.id] || 0);
    const sp = round2(spent[b.id] || 0);
    return {
      ...bucketOut(b),
      allocated,
      spent: sp,
      balance: round2(b.starting_balance + allocated - sp),
    };
  });

  const totalIncome = round2(db.prepare("SELECT COALESCE(SUM(amount),0) s FROM incomes WHERE user_id=?").get(userId).s);
  const totalSplit = round2(
    db.prepare(`SELECT COALESCE(SUM(s.amount),0) s FROM income_splits s JOIN incomes i ON i.id=s.income_id WHERE i.user_id=?`).get(userId).s
  );
  const unassignedSpent = round2(
    db.prepare("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE user_id=? AND bucket_id IS NULL").get(userId).s
  );
  const unassigned = round2(totalIncome - totalSplit - unassignedSpent);

  const ym = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const monthIncome = round2(
    db.prepare("SELECT COALESCE(SUM(amount),0) s FROM incomes WHERE user_id=? AND substr(date,1,7)=?").get(userId, ym).s
  );
  const monthExpenses = round2(
    db.prepare("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE user_id=? AND substr(date,1,7)=?").get(userId, ym).s
  );
  const byCategory = db
    .prepare(
      `SELECT category, SUM(amount) amount FROM expenses WHERE user_id=? AND substr(date,1,7)=?
       GROUP BY category ORDER BY amount DESC`
    )
    .all(userId, ym)
    .map((r) => ({ category: r.category, amount: round2(r.amount) }));

  // Last six calendar months, oldest first.
  const monthly = [];
  for (let k = 5; k >= 0; k--) {
    const d = new Date(now.getFullYear(), now.getMonth() - k, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const inc = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM incomes WHERE user_id=? AND substr(date,1,7)=?").get(userId, key).s;
    const exp = db.prepare("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE user_id=? AND substr(date,1,7)=?").get(userId, key).s;
    const sav = db
      .prepare(
        `SELECT COALESCE(SUM(s.amount),0) s FROM income_splits s
         JOIN incomes i ON i.id=s.income_id JOIN buckets b ON b.id=s.bucket_id
         WHERE i.user_id=? AND b.kind='savings' AND substr(i.date,1,7)=?`
      )
      .get(userId, key).s;
    monthly.push({ month: MONTHS[d.getMonth()], income: round2(inc), expenses: round2(exp), saved: round2(sav) });
  }

  return {
    buckets: out,
    totalAllocatedPercent: round2(buckets.reduce((s, b) => s + b.percent, 0)),
    savedTotal: round2(out.filter((b) => b.kind === "savings").reduce((s, b) => s + b.balance, 0)),
    unassigned,
    totalIncome,
    monthIncome,
    monthExpenses,
    byCategory,
    monthly,
  };
}

/* --------------------------- sample / reset --------------------------- */
export function loadSample(userId, now = new Date()) {
  const tx = db.transaction(() => {
    const buckets = listBuckets(userId);
    const bills = buckets.find((b) => /bill/i.test(b.name)) || buckets.find((b) => b.kind === "spending");
    const personal = buckets.find((b) => /personal|fun|spend/i.test(b.name) && b.id !== bills?.id) || bills;
    const day = (monthsAgo, dom) => {
      const d = new Date(now.getFullYear(), now.getMonth() - monthsAgo, Math.min(dom, 28));
      return d > now ? null : isoDate(d);
    };
    for (let m = 2; m >= 0; m--) {
      for (const dom of [1, 15]) {
        const date = day(m, dom);
        if (date) addIncome(userId, { source: "Paycheck", amount: 2100, date, isPaycheck: true });
      }
      const exp = [
        ["Rent", 1150, "Other", 2, bills],
        ["Electric & internet", 142.35, "Utilities", 5, bills],
        ["Groceries", 96.2, "Groceries", 6, personal],
        ["Groceries", 83.45, "Groceries", 13, personal],
        ["Groceries", 104.1, "Groceries", 20, personal],
        ["Dinner out", 48.75, "Dining", 9, personal],
        ["Lunch", 14.5, "Dining", 11, personal],
        ["Gas", 52.3, "Transport", 8, bills],
        ["Streaming", 15.99, "Subscriptions", 4, personal],
        ["Pharmacy", 22.4, "Health", 17, personal],
        ["Movie night", 31.0, "Entertainment", 19, personal],
      ];
      for (const [description, amount, category, dom, b] of exp) {
        const date = day(m, dom);
        if (date) addExpense(userId, { description, amount, category, date, bucketId: b?.id ?? null });
      }
    }
  });
  tx();
}

export function resetUserData(userId) {
  const tx = db.transaction(() => {
    db.prepare("DELETE FROM bank_txns WHERE item_id IN (SELECT id FROM bank_items WHERE user_id=?)").run(userId);
    db.prepare("UPDATE bank_items SET cursor=NULL, imported=0 WHERE user_id=?").run(userId);
    db.prepare("DELETE FROM incomes WHERE user_id=?").run(userId);
    db.prepare("DELETE FROM expenses WHERE user_id=?").run(userId);
    db.prepare("DELETE FROM messages WHERE user_id=?").run(userId);
    db.prepare("DELETE FROM buckets WHERE user_id=?").run(userId);
    seedDefaultBuckets(userId);
  });
  tx();
}
