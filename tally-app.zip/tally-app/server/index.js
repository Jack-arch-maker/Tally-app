import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import { db } from "./db.js";
import { PRICES, config } from "./config.js";
import { HttpError, hashPassword, round2, sha256, verifyPassword, cleanText } from "./util.js";
import * as B from "./budget.js";
import * as penny from "./penny.js";
import * as billing from "./billing.js";
import * as bank from "./bank.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.resolve(__dirname, "..", "public");

export const app = express();
app.set("trust proxy", 1);
app.disable("x-powered-by");

app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  if (req.path.startsWith("/api/")) res.setHeader("Cache-Control", "no-store");
  next();
});

/* Stripe needs the raw request body to verify its signature, so this goes before express.json(). */
app.post("/api/billing/webhook", express.raw({ type: "*/*", limit: "1mb" }), wrap(async (req, res) => {
  const event = billing.verifyWebhook(req.body.toString("utf8"), req.get("stripe-signature"));
  await billing.handleWebhook(event);
  res.json({ received: true });
}));

app.use(express.json({ limit: "100kb" }));

function wrap(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

/* ------------------------------ sessions ------------------------------ */
const COOKIE = "tally_session";
const SESSION_DAYS = 30;

function readCookie(req, name) {
  for (const part of String(req.headers.cookie || "").split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === name) return decodeURIComponent(v.join("="));
  }
  return null;
}

function createSession(userId) {
  const token = crypto.randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  db.prepare("INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?,?,?)").run(sha256(token), userId, expires);
  return token;
}

function setCookie(req, res, token) {
  const secure = req.secure || config.isProd ? "; Secure" : "";
  res.setHeader(
    "Set-Cookie",
    `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}${secure}`
  );
}
const clearCookie = (res) =>
  res.setHeader("Set-Cookie", `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);

function userForToken(token) {
  if (!token) return null;
  const row = db
    .prepare(
      `SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ? AND s.expires_at > ?`
    )
    .get(sha256(token), new Date().toISOString());
  return row || null;
}

function touchActive(user) {
  const last = user.last_active_at ? Date.parse(user.last_active_at) : 0;
  if (Date.now() - last > 5 * 60_000) {
    db.prepare("UPDATE users SET last_active_at=? WHERE id=?").run(new Date().toISOString(), user.id);
  }
}

const bearer = (req) => {
  const h = req.get("authorization") || "";
  return h.startsWith("Bearer ") ? h.slice(7).trim() : null;
};

/** Every data route requires an explicit Bearer token (never a cookie), which keeps the API CSRF-proof. */
function auth(req, res, next) {
  const token = bearer(req);
  const user = userForToken(token);
  if (!user) return res.status(401).json({ message: "Please sign in." });
  touchActive(user);
  req.user = user;
  req.token = token;
  next();
}
const requirePro = (req, res, next) =>
  B.isPro(req.user) ? next() : res.status(403).json({ message: "That's part of Tally Pro. Upgrade to unlock it." });
const requireAdmin = (req, res, next) =>
  B.isAdminEmail(req.user.email) ? next() : res.status(403).json({ message: "Admins only." });

/* ---------------------------- rate limiting ---------------------------- */
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const e = hits.get(key);
  if (!e || e.reset < now) {
    hits.set(key, { n: 1, reset: now + windowMs });
    return false;
  }
  e.n += 1;
  return e.n > max;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of hits) if (v.reset < now) hits.delete(k);
}, 60_000).unref();

/* -------------------------------- auth -------------------------------- */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const DUMMY_HASH = hashPassword("not-a-real-password");

app.post("/api/auth/signup", wrap(async (req, res) => {
  if (limited(`signup:${req.ip}`, 10, 3600_000)) throw new HttpError(429, "Too many sign-ups from this network. Please try again later.");
  const name = cleanText(req.body?.name, 80);
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  if (!name) throw new HttpError(400, "Please enter your name.");
  if (!EMAIL_RE.test(email)) throw new HttpError(400, "Please enter a valid email address.");
  if (password.length < 8) throw new HttpError(400, "Password must be at least 8 characters.");
  if (password.length > 200) throw new HttpError(400, "That password is too long.");
  if (db.prepare("SELECT 1 FROM users WHERE email=?").get(email)) {
    throw new HttpError(409, "An account with that email already exists. Try signing in.");
  }
  const create = db.transaction(() => {
    const info = db.prepare("INSERT INTO users (name,email,password_hash,last_active_at) VALUES (?,?,?,?)")
      .run(name, email, hashPassword(password), new Date().toISOString());
    B.seedDefaultBuckets(info.lastInsertRowid);
    return info.lastInsertRowid;
  });
  const id = create();
  const token = createSession(id);
  setCookie(req, res, token);
  res.status(201).json({ user: B.publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(id)), token });
}));

app.post("/api/auth/login", wrap(async (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  if (limited(`login:${req.ip}:${email}`, 8, 15 * 60_000) || limited(`login-ip:${req.ip}`, 40, 15 * 60_000)) {
    throw new HttpError(429, "Too many sign-in attempts. Please wait a few minutes and try again.");
  }
  const row = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  const ok = verifyPassword(password, row ? row.password_hash : DUMMY_HASH) && !!row;
  if (!ok) throw new HttpError(401, "That email and password don't match.");
  hits.delete(`login:${req.ip}:${email}`);
  const token = createSession(row.id);
  setCookie(req, res, token);
  touchActive(row);
  res.json({ user: B.publicUser(row), token });
}));

/* Called on every page load. The browser keeps the session in an HttpOnly cookie, and this is the one
   place the cookie is accepted: it trades it for a token the app then sends as a Bearer header. */
app.get("/api/auth/me", (req, res) => {
  const token = bearer(req) || readCookie(req, COOKIE);
  const user = userForToken(token);
  if (!user) {
    if (readCookie(req, COOKIE)) clearCookie(res);
    return res.json({ user: null });
  }
  touchActive(user);
  res.json({ user: B.publicUser(user), token });
});

app.post("/api/auth/logout", (req, res) => {
  for (const t of [bearer(req), readCookie(req, COOKIE)]) {
    if (t) db.prepare("DELETE FROM sessions WHERE token_hash=?").run(sha256(t));
  }
  clearCookie(res);
  res.json({ ok: true });
});

/* ------------------------------ budget data ------------------------------ */
app.get("/api/summary", auth, (req, res) => res.json(B.summary(req.user.id)));

app.get("/api/buckets", auth, (req, res) => res.json(B.listBuckets(req.user.id)));
app.post("/api/buckets", auth, (req, res) => res.status(201).json(B.createBucket(req.user, req.body || {})));
app.patch("/api/buckets/:id", auth, (req, res) => res.json(B.updateBucket(req.user, Number(req.params.id), req.body || {})));
app.delete("/api/buckets/:id", auth, (req, res) => (B.deleteBucket(req.user, Number(req.params.id)), res.json({ ok: true })));

app.get("/api/incomes", auth, (req, res) => res.json(B.listIncomes(req.user.id)));
app.post("/api/incomes", auth, (req, res) => {
  const { income, split } = B.addIncome(req.user.id, {
    source: req.body?.source,
    amount: req.body?.amount,
    date: req.body?.date,
    isPaycheck: req.body?.isPaycheck !== false,
  });
  res.status(201).json({ ...income, split });
});
app.delete("/api/incomes/:id", auth, (req, res) => (B.deleteIncome(req.user.id, Number(req.params.id)), res.json({ ok: true })));

app.get("/api/expenses", auth, (req, res) => res.json(B.listExpenses(req.user.id)));
app.post("/api/expenses", auth, (req, res) => res.status(201).json(B.addExpense(req.user.id, req.body || {})));
app.delete("/api/expenses/:id", auth, (req, res) => (B.deleteExpense(req.user.id, Number(req.params.id)), res.json({ ok: true })));

app.post("/api/sample", auth, (req, res) => (B.loadSample(req.user.id), res.json({ ok: true })));
app.post("/api/reset", auth, (req, res) => (B.resetUserData(req.user.id), res.json({ ok: true })));

/* --------------------------------- Penny --------------------------------- */
app.get("/api/messages", auth, requirePro, (req, res) => res.json(penny.listMessages(req.user.id)));
app.delete("/api/messages", auth, (req, res) => (db.prepare("DELETE FROM messages WHERE user_id=?").run(req.user.id), res.json({ ok: true })));
app.post("/api/chat", auth, requirePro, wrap(async (req, res) => {
  const text = cleanText(req.body?.message, 2000);
  if (!text) throw new HttpError(400, "Say something and I'll help.");
  if (limited(`chat:${req.user.id}`, 40, 10 * 60_000)) throw new HttpError(429, "Penny needs a breather. Try again in a few minutes.");
  res.json(await penny.chat(req.user, text));
}));
app.post("/api/insight", auth, requirePro, wrap(async (req, res) => {
  if (limited(`insight:${req.user.id}`, 20, 10 * 60_000)) throw new HttpError(429, "Give it a few minutes before asking again.");
  res.json(await penny.insight(req.user));
}));

/* -------------------------------- billing -------------------------------- */
app.get("/api/billing/config", auth, (req, res) => res.json({ enabled: billing.billingEnabled() }));
app.post("/api/billing/checkout", auth, wrap(async (req, res) => {
  if (B.isAdminEmail(req.user.email)) throw new HttpError(400, "Admin accounts always have Pro.");
  res.json(await billing.createCheckout(req, req.user, req.body?.interval));
}));
app.post("/api/billing/portal", auth, wrap(async (req, res) => res.json(await billing.createPortal(req, req.user))));
app.post("/api/billing/sync", auth, wrap(async (req, res) => {
  try {
    await billing.syncPlan(req.user);
  } catch (e) {
    console.error("billing sync failed:", e.message);
  }
  res.json({ user: B.publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id)) });
}));

/* ---------------------------------- bank --------------------------------- */
app.get("/api/bank/config", auth, (req, res) => res.json({ enabled: bank.bankEnabled(), env: config.plaid.env }));
app.get("/api/bank/items", auth, requirePro, (req, res) => res.json(bank.listItems(req.user.id)));
app.post("/api/bank/link-token", auth, requirePro, wrap(async (req, res) => res.json(await bank.createLinkToken(req.user))));
app.post("/api/bank/exchange", auth, requirePro, wrap(async (req, res) =>
  res.json(await bank.exchange(req.user, req.body?.publicToken, req.body?.institution))));
app.post("/api/bank/sync", auth, requirePro, wrap(async (req, res) => res.json(await bank.syncAll(req.user.id))));
app.delete("/api/bank/items/:id", auth, requirePro, wrap(async (req, res) => {
  await bank.removeItem(req.user.id, Number(req.params.id));
  res.json({ ok: true });
}));

/* --------------------------------- admin --------------------------------- */
app.get("/api/admin/users", auth, requireAdmin, (req, res) => {
  const rows = db
    .prepare(
      `SELECT u.*,
        (SELECT COUNT(*) FROM incomes i WHERE i.user_id=u.id) + (SELECT COUNT(*) FROM expenses e WHERE e.user_id=u.id) AS entries
       FROM users u ORDER BY u.created_at DESC, u.id DESC`
    )
    .all();
  const weekAgo = new Date(Date.now() - 7 * 864e5).toISOString();
  let mrr = 0;
  const users = rows.map((r) => {
    const admin = B.isAdminEmail(r.email);
    if (!admin && r.plan === "pro" && r.plan_source === "stripe") {
      mrr += r.plan_interval === "month" ? PRICES.month : PRICES.year / 12;
    }
    return {
      id: r.id, name: r.name, email: r.email, isAdmin: admin, plan: admin ? "pro" : r.plan,
      createdAt: r.created_at, lastActiveAt: r.last_active_at, entries: r.entries,
    };
  });
  res.json({
    users,
    stats: {
      totalUsers: rows.length,
      proUsers: users.filter((u) => u.plan === "pro" && !u.isAdmin).length,
      mrr: round2(mrr),
      newThisWeek: rows.filter((r) => r.created_at >= weekAgo).length,
      activeThisWeek: rows.filter((r) => r.last_active_at && r.last_active_at >= weekAgo).length,
    },
  });
});

app.patch("/api/admin/users/:id", auth, requireAdmin, (req, res) => {
  const plan = req.body?.plan;
  if (!["free", "pro"].includes(plan)) throw new HttpError(400, "Plan must be free or pro.");
  const target = db.prepare("SELECT * FROM users WHERE id=?").get(Number(req.params.id));
  if (!target) throw new HttpError(404, "User not found.");
  if (B.isAdminEmail(target.email)) throw new HttpError(400, "Admin accounts always have Pro.");
  if (plan === "pro") {
    db.prepare("UPDATE users SET plan='pro', plan_source='manual', plan_interval=NULL, plan_renews_at=NULL WHERE id=?").run(target.id);
  } else {
    db.prepare("UPDATE users SET plan='free', plan_source='none', plan_interval=NULL, plan_renews_at=NULL WHERE id=?").run(target.id);
  }
  res.json({ ok: true });
});

app.delete("/api/admin/users/:id", auth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) throw new HttpError(400, "You can't delete your own account here.");
  const info = db.prepare("DELETE FROM users WHERE id=?").run(id);
  if (!info.changes) throw new HttpError(404, "User not found.");
  res.json({ ok: true });
});

/* ------------------------------ static + errors ------------------------------ */
app.get("/healthz", (req, res) => res.json({ ok: true }));
app.use("/api", (req, res) => res.status(404).json({ message: "Not found." }));

app.use(express.static(PUBLIC_DIR, { index: false, maxAge: "1h", setHeaders: (res, p) => {
  if (p.endsWith("index.html")) res.setHeader("Cache-Control", "no-cache");
} }));
app.get("*", (req, res) => {
  res.setHeader("Cache-Control", "no-cache");
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof HttpError) return res.status(err.status).json({ message: err.message });
  if (err.type === "entity.parse.failed") return res.status(400).json({ message: "That request couldn't be read." });
  if (err.type === "entity.too.large") return res.status(413).json({ message: "That request is too large." });
  console.error(err);
  res.status(500).json({ message: "Something went wrong on our side. Please try again." });
});

/* Expired sessions are cleaned up hourly. */
setInterval(() => db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(new Date().toISOString()), 3600_000).unref();

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  app.listen(config.port, () => {
    console.log(`Tally is running on http://localhost:${config.port}`);
    console.log(`  Penny (Anthropic): ${penny.pennyEnabled() ? "on" : "off (set ANTHROPIC_API_KEY)"}`);
    console.log(`  Billing (Stripe):  ${billing.billingEnabled() ? "on" : "off (set STRIPE_SECRET_KEY)"}`);
    console.log(`  Banks (Plaid):     ${bank.bankEnabled() ? `on (${config.plaid.env})` : "off (set PLAID_CLIENT_ID / PLAID_SECRET)"}`);
    console.log(`  Admins: ${config.adminEmails.join(", ") || "none (set ADMIN_EMAIL)"}`);
  });
}
