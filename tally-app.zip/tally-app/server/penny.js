import { db } from "./db.js";
import { CATEGORIES, config } from "./config.js";
import {
  addExpense, addIncome, createBucket, deleteBucket, listBuckets, listExpenses, listIncomes,
  summary, updateBucket,
} from "./budget.js";
import { HttpError, isoDate } from "./util.js";

const usd = (n) => "$" + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export const pennyEnabled = () => !!config.anthropic.apiKey;

async function callClaude({ system, messages, tools, maxTokens = 1024 }) {
  if (!pennyEnabled()) {
    throw new HttpError(503, "Penny isn't switched on yet. The site owner needs to add an Anthropic API key.");
  }
  let res;
  try {
    res = await fetch(`${config.anthropic.baseUrl}/v1/messages`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": config.anthropic.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: config.anthropic.model,
        max_tokens: maxTokens,
        system,
        messages,
        ...(tools ? { tools } : {}),
      }),
      signal: AbortSignal.timeout(45_000),
    });
  } catch (e) {
    console.error("Anthropic request failed:", e.message);
    throw new HttpError(502, "Penny couldn't be reached just now. Please try again in a moment.");
  }
  if (!res.ok) {
    console.error("Anthropic error", res.status, (await res.text()).slice(0, 500));
    throw new HttpError(502, "Penny ran into a problem. Please try again in a moment.");
  }
  return res.json();
}

/* ---------------------------- context snapshot ---------------------------- */
function snapshot(userId, user) {
  const s = summary(userId);
  const today = isoDate();
  const lines = [];
  lines.push(`Today is ${today}. The person is ${user.name}.`);
  lines.push(`Buckets (${s.totalAllocatedPercent}% of each paycheck assigned, ${Math.max(0, 100 - s.totalAllocatedPercent)}% unassigned):`);
  for (const b of s.buckets) {
    lines.push(
      `- ${b.name} [${b.kind}] ${b.percent}% · balance ${usd(b.balance)}` +
        (b.goal ? ` · goal ${usd(b.goal)} (${Math.round((b.balance / b.goal) * 100)}%)` : "") +
        ` · received ${usd(b.allocated)}, spent ${usd(b.spent)}, started with ${usd(b.startingBalance)}`
    );
  }
  lines.push(`Unassigned money: ${usd(s.unassigned)}. Total saved (savings buckets): ${usd(s.savedTotal)}.`);
  lines.push(`This month: income ${usd(s.monthIncome)}, spending ${usd(s.monthExpenses)}, net ${usd(s.monthIncome - s.monthExpenses)}.`);
  if (s.byCategory.length) {
    lines.push("This month's spending by category: " + s.byCategory.map((c) => `${c.category} ${usd(c.amount)}`).join(", ") + ".");
  }
  lines.push("Last six months (income / spending / saved): " + s.monthly.map((m) => `${m.month} ${usd(m.income)}/${usd(m.expenses)}/${usd(m.saved)}`).join("; ") + ".");
  const recent = [
    ...listIncomes(userId).slice(0, 8).map((i) => ({ d: i.date, t: `+${usd(i.amount)} ${i.source}${i.isPaycheck ? " (paycheck)" : ""}` })),
    ...listExpenses(userId).slice(0, 12).map((e) => ({ d: e.date, t: `-${usd(e.amount)} ${e.description} [${e.category}]` })),
  ]
    .sort((a, b) => b.d.localeCompare(a.d))
    .slice(0, 14);
  if (recent.length) lines.push("Recent entries:\n" + recent.map((r) => `- ${r.d} ${r.t}`).join("\n"));
  else lines.push("Nothing has been logged yet.");
  return lines.join("\n");
}

const PERSONA = `You are Penny, the friendly budgeting helper inside Tally, an app that splits every paycheck into "buckets" by percentage.
Voice: warm, calm, plain-spoken, never preachy or judgmental. Keep replies short (usually 2-5 sentences). Use the person's real numbers from the budget snapshot; never invent figures. Use US dollars.
Formatting: plain text only. You may use **bold** for key numbers and simple "- " bullet lists. No headings, tables or emoji.
You are a helper, not a financial advisor: give practical budgeting suggestions, and for tax, legal, investment or debt-strategy questions say so briefly and keep it general.
Actions: you can log expenses and income and change buckets using your tools. Log an expense or income when the person tells you they spent or earned something. Only create, change or delete buckets when they clearly ask you to. If an amount is missing or ambiguous, ask instead of guessing. After using tools, confirm in one or two sentences exactly what you did. Never claim you logged something unless a tool call succeeded.
If asked "can I afford this?", compare the amount to the relevant bucket balance and unassigned money, and be honest.`;

/* --------------------------------- tools --------------------------------- */
const TOOLS = [
  {
    name: "log_expense",
    description: "Record money the person spent. Use today's date unless they say otherwise.",
    input_schema: {
      type: "object",
      properties: {
        description: { type: "string", description: "Short label, e.g. 'Lunch' or 'Gas'" },
        amount: { type: "number", description: "Dollar amount, positive" },
        category: { type: "string", enum: CATEGORIES },
        date: { type: "string", description: "YYYY-MM-DD; omit for today" },
        bucket: { type: "string", description: "Name of the bucket it came out of, if clear from the conversation; otherwise omit" },
      },
      required: ["description", "amount", "category"],
    },
  },
  {
    name: "log_income",
    description: "Record money the person received. Paychecks are automatically split across their buckets.",
    input_schema: {
      type: "object",
      properties: {
        source: { type: "string", description: "e.g. 'Paycheck', 'Freelance', 'Gift'" },
        amount: { type: "number" },
        date: { type: "string", description: "YYYY-MM-DD; omit for today" },
        is_paycheck: { type: "boolean", description: "true to split across buckets (default true); false for one-off money that stays unassigned" },
      },
      required: ["source", "amount"],
    },
  },
  {
    name: "save_bucket",
    description:
      "Create a bucket, or update the existing bucket with the same name. Only use when the person asks to set up or change their plan.",
    input_schema: {
      type: "object",
      properties: {
        name: { type: "string" },
        new_name: { type: "string", description: "Rename the bucket" },
        percent: { type: "number", description: "Percent of each paycheck, 0-100" },
        kind: { type: "string", enum: ["spending", "savings"] },
        goal: { type: ["number", "null"], description: "Savings goal in dollars; null to clear" },
        starting_balance: { type: "number", description: "Money already in the bucket" },
      },
      required: ["name"],
    },
  },
  {
    name: "delete_bucket",
    description: "Delete a bucket by name. Only when the person asks.",
    input_schema: { type: "object", properties: { name: { type: "string" } }, required: ["name"] },
  },
];

const findBucket = (userId, name) => {
  const n = String(name || "").trim().toLowerCase();
  return listBuckets(userId).find((b) => b.name.toLowerCase() === n);
};

function runTool(user, name, input) {
  const uid = user.id;
  switch (name) {
    case "log_expense": {
      let bucketId = null;
      if (input.bucket) {
        const b = findBucket(uid, input.bucket);
        if (!b) throw new Error(`No bucket named "${input.bucket}".`);
        bucketId = b.id;
      }
      const e = addExpense(uid, { ...input, bucketId });
      return {
        result: `Logged expense ${e.description} ${usd(e.amount)} (${e.category}) on ${e.date}${bucketId ? ` from ${input.bucket}` : ""}.`,
        action: `Logged expense: ${e.description} · ${usd(e.amount)}`,
      };
    }
    case "log_income": {
      const isPaycheck = input.is_paycheck !== false;
      const { income, split } = addIncome(uid, { ...input, isPaycheck });
      const buckets = Object.fromEntries(listBuckets(uid).map((b) => [b.id, b.name]));
      const detail = isPaycheck
        ? " Split: " + split.parts.map((p) => `${buckets[p.bucketId]} ${usd(p.amount)}`).join(", ") + (split.unassigned > 0 ? `, unassigned ${usd(split.unassigned)}` : "") + "."
        : " Kept unassigned.";
      return {
        result: `Logged income ${income.source} ${usd(income.amount)} on ${income.date}.${detail}`,
        action: `Logged ${isPaycheck ? "paycheck" : "income"}: ${income.source} · ${usd(income.amount)}`,
      };
    }
    case "save_bucket": {
      const existing = findBucket(uid, input.name);
      const patch = {};
      if (input.percent !== undefined) patch.percent = input.percent;
      if (input.kind !== undefined) patch.kind = input.kind;
      if (input.goal !== undefined) patch.goal = input.goal;
      if (input.starting_balance !== undefined) patch.startingBalance = input.starting_balance;
      let b;
      if (existing) {
        if (input.new_name) patch.name = input.new_name;
        b = updateBucket(user, existing.id, patch);
      } else {
        b = createBucket(user, { name: input.new_name || input.name, ...patch });
      }
      const total = listBuckets(uid).reduce((s, x) => s + x.percent, 0);
      return {
        result: `${existing ? "Updated" : "Created"} bucket "${b.name}" (${b.percent}%, ${b.kind}${b.goal ? `, goal ${usd(b.goal)}` : ""}). Buckets now total ${Math.round(total * 100) / 100}% of each paycheck${total > 100 ? " — over 100%, warn the person" : ""}.`,
        action: `${existing ? "Updated" : "Created"} bucket: ${b.name} · ${b.percent}%`,
      };
    }
    case "delete_bucket": {
      const b = findBucket(uid, input.name);
      if (!b) throw new Error(`No bucket named "${input.name}".`);
      deleteBucket(uid, b.id);
      return { result: `Deleted bucket "${b.name}".`, action: `Deleted bucket: ${b.name}` };
    }
    default:
      throw new Error(`Unknown tool ${name}`);
  }
}

/* ---------------------------------- chat ---------------------------------- */
function normalizeHistory(rows) {
  const out = [];
  for (const r of rows) {
    const last = out[out.length - 1];
    if (last && last.role === r.role) last.content += "\n\n" + r.content;
    else out.push({ role: r.role, content: r.content });
  }
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}

export async function chat(user, userText) {
  const uid = user.id;
  const rows = db.prepare("SELECT role, content FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 20").all(uid).reverse();
  const messages = normalizeHistory([...rows, { role: "user", content: userText }]);
  const actions = [];
  let finalText = "";

  for (let step = 0; step < 6; step++) {
    // Rebuild the snapshot each step so it reflects anything just logged.
    const system = `${PERSONA}\n\n--- BUDGET SNAPSHOT ---\n${snapshot(uid, user)}`;
    const reply = await callClaude({ system, messages, tools: TOOLS });
    const text = (reply.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
    const calls = (reply.content || []).filter((b) => b.type === "tool_use");
    if (!calls.length || reply.stop_reason !== "tool_use") {
      finalText = text;
      break;
    }
    messages.push({ role: "assistant", content: reply.content });
    const results = [];
    for (const c of calls) {
      try {
        const r = runTool(user, c.name, c.input || {});
        actions.push(r.action);
        results.push({ type: "tool_result", tool_use_id: c.id, content: r.result });
      } catch (e) {
        results.push({ type: "tool_result", tool_use_id: c.id, content: `Failed: ${e.message}`, is_error: true });
      }
    }
    messages.push({ role: "user", content: results });
    finalText = text; // fallback if we run out of steps
  }

  if (!finalText) finalText = actions.length ? "Done — I've taken care of that." : "Sorry, I couldn't come up with an answer. Could you try rephrasing?";

  const save = db.transaction(() => {
    db.prepare("INSERT INTO messages (user_id, role, content) VALUES (?, 'user', ?)").run(uid, userText);
    const info = db.prepare("INSERT INTO messages (user_id, role, content) VALUES (?, 'assistant', ?)").run(uid, finalText);
    return db.prepare("SELECT id, role, content, created_at AS createdAt FROM messages WHERE id=?").get(info.lastInsertRowid);
  });
  return { message: save(), actions };
}

export function listMessages(userId) {
  return db.prepare("SELECT id, role, content, created_at AS createdAt FROM messages WHERE user_id=? ORDER BY id").all(userId);
}

/* -------------------------------- insight -------------------------------- */
export async function insight(user) {
  const system = `${PERSONA}\n\nRight now you are writing the short "Penny's take" card on the Overview page. Write exactly one specific observation about the person's budget followed by one concrete next step. 2-3 sentences total, no greeting, no bullet list, no tools. If nothing has been logged yet, suggest the very first step instead.\n\n--- BUDGET SNAPSHOT ---\n${snapshot(user.id, user)}`;
  const reply = await callClaude({
    system,
    messages: [{ role: "user", content: "Give me Penny's take." }],
    maxTokens: 300,
  });
  const text = (reply.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
  return { text: text || null };
}
