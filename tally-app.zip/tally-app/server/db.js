import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";

fs.mkdirSync(config.dataDir, { recursive: true });
export const db = new Database(process.env.DB_FILE || path.join(config.dataDir, "tally.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free',            -- 'free' | 'pro'
  plan_source TEXT NOT NULL DEFAULT 'none',     -- 'none' | 'stripe' | 'manual'
  plan_interval TEXT,                           -- 'month' | 'year'
  plan_renews_at TEXT,
  stripe_customer_id TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_active_at TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  expires_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS buckets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  percent REAL NOT NULL DEFAULT 0,
  kind TEXT NOT NULL DEFAULT 'spending',        -- 'spending' | 'savings'
  goal REAL,
  starting_balance REAL NOT NULL DEFAULT 0,
  color TEXT NOT NULL DEFAULT '1',
  position INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_buckets_user ON buckets(user_id);

CREATE TABLE IF NOT EXISTS incomes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source TEXT NOT NULL,
  amount REAL NOT NULL,
  date TEXT NOT NULL,
  is_paycheck INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_incomes_user_date ON incomes(user_id, date);

-- How each paycheck was split at the time it was added (past splits never change).
CREATE TABLE IF NOT EXISTS income_splits (
  income_id INTEGER NOT NULL REFERENCES incomes(id) ON DELETE CASCADE,
  bucket_id INTEGER NOT NULL REFERENCES buckets(id) ON DELETE CASCADE,
  amount REAL NOT NULL,
  PRIMARY KEY (income_id, bucket_id)
);

CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  description TEXT NOT NULL,
  amount REAL NOT NULL,
  category TEXT NOT NULL DEFAULT 'Other',
  date TEXT NOT NULL,
  bucket_id INTEGER REFERENCES buckets(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_expenses_user_date ON expenses(user_id, date);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL,                            -- 'user' | 'assistant'
  content TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, id);

CREATE TABLE IF NOT EXISTS bank_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plaid_item_id TEXT NOT NULL,
  access_token_enc TEXT NOT NULL,
  institution TEXT NOT NULL,
  cursor TEXT,
  last_synced_at TEXT,
  imported INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_bank_items_user ON bank_items(user_id);

-- Remembers which entries came from which bank transaction (dedupe + removals).
CREATE TABLE IF NOT EXISTS bank_txns (
  item_id INTEGER NOT NULL REFERENCES bank_items(id) ON DELETE CASCADE,
  txn_id TEXT NOT NULL,
  kind TEXT NOT NULL,                            -- 'expense' | 'income'
  entry_id INTEGER NOT NULL,
  PRIMARY KEY (item_id, txn_id)
);
`);
