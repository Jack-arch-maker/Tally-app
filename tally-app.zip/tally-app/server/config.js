import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const env = process.env;

export const config = {
  port: Number(env.PORT) || 5000,
  isProd: env.NODE_ENV === "production",
  dataDir: env.DATA_DIR || path.resolve(process.cwd(), "data"),
  // Public URL of the site (used for cookies / redirects). Optional.
  publicUrl: env.PUBLIC_URL || "",
  adminEmails: (env.ADMIN_EMAIL || "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean),

  anthropic: {
    apiKey: env.ANTHROPIC_API_KEY || "",
    model: env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
    baseUrl: env.ANTHROPIC_BASE_URL || "https://api.anthropic.com",
  },
  stripe: {
    secretKey: env.STRIPE_SECRET_KEY || "",
    webhookSecret: env.STRIPE_WEBHOOK_SECRET || "",
    baseUrl: env.STRIPE_BASE_URL || "https://api.stripe.com",
    // Optional: use your own Stripe Price IDs instead of the built-in $11.99 / $79.99 prices.
    priceMonth: env.STRIPE_PRICE_MONTH || "",
    priceYear: env.STRIPE_PRICE_YEAR || "",
  },
  plaid: {
    clientId: env.PLAID_CLIENT_ID || "",
    secret: env.PLAID_SECRET || "",
    env: env.PLAID_ENV || "sandbox",
    baseUrl:
      env.PLAID_BASE_URL ||
      (env.PLAID_ENV === "production" ? "https://production.plaid.com" : "https://sandbox.plaid.com"),
  },
};

// A stable secret for encrypting bank tokens. If APP_SECRET isn't provided we generate one
// and keep it next to the database so restarts don't lock you out of stored tokens.
function loadSecret() {
  if (env.APP_SECRET) return env.APP_SECRET;
  fs.mkdirSync(config.dataDir, { recursive: true });
  const file = path.join(config.dataDir, ".app_secret");
  if (fs.existsSync(file)) return fs.readFileSync(file, "utf8").trim();
  const s = crypto.randomBytes(32).toString("hex");
  fs.writeFileSync(file, s, { mode: 0o600 });
  return s;
}
export const appSecret = loadSecret();

export const PRICES = { month: 11.99, year: 79.99 };
export const FREE_BUCKET_LIMIT = 4;
export const CATEGORIES = [
  "Groceries", "Dining", "Transport", "Utilities", "Subscriptions",
  "Health", "Shopping", "Entertainment", "Personal", "Debt", "Other",
];
