import { db } from "./db.js";
import { config } from "./config.js";
import { addExpense, addIncome } from "./budget.js";
import { HttpError, decrypt, encrypt, isoDate, round2 } from "./util.js";

export const bankEnabled = () => !!(config.plaid.clientId && config.plaid.secret);

async function plaid(path, body) {
  if (!bankEnabled()) throw new HttpError(503, "Bank connections aren't switched on yet.");
  let res;
  try {
    res = await fetch(`${config.plaid.baseUrl}${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ client_id: config.plaid.clientId, secret: config.plaid.secret, ...body }),
      signal: AbortSignal.timeout(30_000),
    });
  } catch (e) {
    console.error("Plaid request failed:", e.message);
    throw new HttpError(502, "Couldn't reach the bank connector. Please try again.");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new HttpError(502, data.error_message || "The bank connector returned an error.");
    err.plaidCode = data.error_code;
    console.error("Plaid error", path, data.error_code, data.error_message);
    throw err;
  }
  return data;
}

export async function createLinkToken(user) {
  const data = await plaid("/link/token/create", {
    client_name: "Tally",
    language: "en",
    country_codes: ["US"],
    user: { client_user_id: String(user.id) },
    products: ["transactions"],
    transactions: { days_requested: 90 },
  });
  return { linkToken: data.link_token };
}

export function listItems(userId) {
  return db
    .prepare("SELECT id, institution, last_synced_at AS lastSyncedAt, imported FROM bank_items WHERE user_id=? ORDER BY id")
    .all(userId);
}

export async function exchange(user, publicToken, institution) {
  if (!publicToken) throw new HttpError(400, "Missing bank token.");
  const data = await plaid("/item/public_token/exchange", { public_token: publicToken });
  const name = String(institution || "Your bank").slice(0, 80);
  const info = db
    .prepare("INSERT INTO bank_items (user_id, plaid_item_id, access_token_enc, institution) VALUES (?,?,?,?)")
    .run(user.id, data.item_id, encrypt(data.access_token), name);
  let added = 0;
  try {
    ({ added } = await syncItem(user.id, info.lastInsertRowid));
  } catch {
    /* history may not be ready yet; the Sync button will pick it up */
  }
  return { institution: name, added };
}

export async function removeItem(userId, id) {
  const item = db.prepare("SELECT * FROM bank_items WHERE id=? AND user_id=?").get(id, userId);
  if (!item) throw new HttpError(404, "Bank not found.");
  try {
    await plaid("/item/remove", { access_token: decrypt(item.access_token_enc) });
  } catch {
    /* even if Plaid is unreachable, drop it on our side */
  }
  db.prepare("DELETE FROM bank_items WHERE id=?").run(id); // bank_txns cascade; imported entries stay
}

/* Plaid's high-level categories → Tally's categories */
const CATEGORY_MAP = {
  FOOD_AND_DRINK: "Dining",
  TRANSPORTATION: "Transport",
  TRAVEL: "Transport",
  RENT_AND_UTILITIES: "Utilities",
  GENERAL_MERCHANDISE: "Shopping",
  HOME_IMPROVEMENT: "Shopping",
  MEDICAL: "Health",
  PERSONAL_CARE: "Personal",
  ENTERTAINMENT: "Entertainment",
  LOAN_PAYMENTS: "Debt",
  GENERAL_SERVICES: "Other",
  GOVERNMENT_AND_NON_PROFIT: "Other",
  BANK_FEES: "Other",
};
function mapCategory(t) {
  const primary = t.personal_finance_category?.primary || "";
  const detailed = t.personal_finance_category?.detailed || "";
  if (/GROCER/.test(detailed)) return "Groceries";
  if (/SUBSCRIPTION|STREAMING|TV_AND_MOVIES|MUSIC/.test(detailed)) return "Subscriptions";
  return CATEGORY_MAP[primary] || "Other";
}

function importTransaction(userId, itemId, t) {
  if (t.pending) return 0; // wait until it posts
  const exists = db.prepare("SELECT 1 FROM bank_txns WHERE item_id=? AND txn_id=?").get(itemId, t.transaction_id);
  if (exists) return 0;
  const primary = t.personal_finance_category?.primary || "";
  if (primary === "TRANSFER_IN" || primary === "TRANSFER_OUT") return 0; // avoid double-counting moves between your own accounts
  const date = t.date || isoDate();
  const label = (t.merchant_name || t.name || "Bank transaction").slice(0, 80);
  const amount = round2(Math.abs(t.amount));
  if (!amount) return 0;
  let kind, entryId;
  if (t.amount > 0) {
    kind = "expense";
    entryId = addExpense(userId, { description: label, amount, category: mapCategory(t), date, bucketId: null }).id;
  } else {
    kind = "income";
    const isPaycheck = primary === "INCOME" && /WAGES|PAYROLL|SALARY/.test(t.personal_finance_category?.detailed || "WAGES");
    entryId = addIncome(userId, { source: label, amount, date, isPaycheck }).income.id;
  }
  db.prepare("INSERT INTO bank_txns (item_id, txn_id, kind, entry_id) VALUES (?,?,?,?)").run(itemId, t.transaction_id, kind, entryId);
  return 1;
}

function removeTransaction(itemId, txnId) {
  const row = db.prepare("SELECT * FROM bank_txns WHERE item_id=? AND txn_id=?").get(itemId, txnId);
  if (!row) return;
  db.prepare(row.kind === "expense" ? "DELETE FROM expenses WHERE id=?" : "DELETE FROM incomes WHERE id=?").run(row.entry_id);
  db.prepare("DELETE FROM bank_txns WHERE item_id=? AND txn_id=?").run(itemId, txnId);
}

/** Pull new transactions for one linked bank. Returns { added, notReady }. */
export async function syncItem(userId, itemId) {
  const item = db.prepare("SELECT * FROM bank_items WHERE id=? AND user_id=?").get(itemId, userId);
  if (!item) throw new HttpError(404, "Bank not found.");
  const access = decrypt(item.access_token_enc);
  let cursor = item.cursor || undefined;
  let added = 0;
  try {
    for (let page = 0; page < 40; page++) {
      const data = await plaid("/transactions/sync", { access_token: access, ...(cursor ? { cursor } : {}), count: 250 });
      const tx = db.transaction(() => {
        for (const t of data.added || []) added += importTransaction(userId, item.id, t);
        for (const t of data.modified || []) {
          removeTransaction(item.id, t.transaction_id);
          added += importTransaction(userId, item.id, t);
        }
        for (const r of data.removed || []) removeTransaction(item.id, r.transaction_id);
      });
      tx();
      cursor = data.next_cursor;
      db.prepare("UPDATE bank_items SET cursor=? WHERE id=?").run(cursor, item.id);
      if (!data.has_more) break;
    }
  } catch (e) {
    if (e.plaidCode === "PRODUCT_NOT_READY") return { added: 0, notReady: true };
    throw e;
  }
  db.prepare("UPDATE bank_items SET last_synced_at=?, imported=imported+? WHERE id=?").run(new Date().toISOString(), added, item.id);
  return { added, notReady: false };
}

export async function syncAll(userId) {
  let added = 0;
  let notReady = false;
  for (const it of db.prepare("SELECT id FROM bank_items WHERE user_id=?").all(userId)) {
    const r = await syncItem(userId, it.id);
    added += r.added;
    notReady ||= r.notReady;
  }
  return { added, notReady };
}
