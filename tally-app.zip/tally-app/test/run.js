import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { startMocks, state } from "./mocks.js";

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "tally-test-"));
const mocks = await startMocks();
Object.assign(process.env, {
  DATA_DIR: tmp,
  ADMIN_EMAIL: "boss@tally.test",
  ANTHROPIC_API_KEY: "sk-test",
  ANTHROPIC_BASE_URL: mocks.anthropic.url,
  STRIPE_SECRET_KEY: "sk_test_123",
  STRIPE_WEBHOOK_SECRET: "whsec_test",
  STRIPE_BASE_URL: mocks.stripe.url,
  PLAID_CLIENT_ID: "cid",
  PLAID_SECRET: "psecret",
  PLAID_BASE_URL: mocks.plaid.url,
});

const { app } = await import("../server/index.js");
const server = await new Promise((r) => { const s = app.listen(0, "127.0.0.1", () => r(s)); });
const base = `http://127.0.0.1:${server.address().port}`;

/* ------------------------------ tiny harness ------------------------------ */
let passed = 0, failed = 0, section = "";
const ok = (cond, msg, extra) => {
  if (cond) passed++;
  else { failed++; console.log(`  ✗ [${section}] ${msg}`, extra !== undefined ? JSON.stringify(extra) : ""); }
};
const eq = (a, b, msg) => ok(JSON.stringify(a) === JSON.stringify(b), `${msg} (got ${JSON.stringify(a)}, want ${JSON.stringify(b)})`);
const near = (a, b, msg) => ok(Math.abs(a - b) < 0.005, `${msg} (got ${a}, want ${b})`);
const group = (name) => { section = name; console.log("• " + name); };

async function api(method, url, { token, body, headers = {}, raw } = {}) {
  const res = await fetch(base + url, {
    method,
    headers: { ...(body ? { "content-type": "application/json" } : {}), ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: raw ?? (body ? JSON.stringify(body) : undefined),
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data, headers: res.headers };
}
const signup = async (name, email, password = "password123") => {
  const r = await api("POST", "/api/auth/signup", { body: { name, email, password } });
  return { ...r, token: r.data.token, user: r.data.user };
};
const today = new Date();
const pad = (n) => String(n).padStart(2, "0");
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const TODAY = ymd(today);

try {
  /* ================================ AUTH ================================ */
  group("auth: signup, login, session");
  let r = await api("POST", "/api/auth/signup", { body: { name: "", email: "a@x.com", password: "password123" } });
  eq(r.status, 400, "empty name rejected");
  r = await api("POST", "/api/auth/signup", { body: { name: "A", email: "nope", password: "password123" } });
  eq(r.status, 400, "bad email rejected");
  r = await api("POST", "/api/auth/signup", { body: { name: "A", email: "a@x.com", password: "short" } });
  eq(r.data.message, "Password must be at least 8 characters.", "short password message");

  const alice = await signup("Alice Adams", "Alice@Example.com");
  eq(alice.status, 201, "signup ok");
  eq(alice.user.email, "alice@example.com", "email lower-cased");
  eq(alice.user.plan, "free", "new users are free");
  eq(alice.user.isAdmin, false, "not admin");
  ok(!JSON.stringify(alice.user).includes("password"), "no password in user payload");
  ok(/HttpOnly/.test(alice.headers.get("set-cookie") || ""), "session cookie is HttpOnly");

  r = await api("POST", "/api/auth/signup", { body: { name: "Dup", email: "ALICE@example.com", password: "password123" } });
  eq(r.status, 409, "duplicate email is 409");

  r = await api("GET", "/api/summary");
  eq(r.status, 401, "no token → 401");
  r = await api("GET", "/api/summary", { token: "bogus" });
  eq(r.status, 401, "bad token → 401");

  // /me restores the session from the cookie alone (what a page refresh does)
  const cookie = alice.headers.get("set-cookie").split(";")[0];
  r = await api("GET", "/api/auth/me", { headers: { cookie } });
  eq(r.data.user?.email, "alice@example.com", "/me works from cookie");
  ok(!!r.data.token, "/me hands back a token");
  r = await api("GET", "/api/auth/me");
  eq(r.data, { user: null }, "/me with nothing → user null");
  // cookie must NOT authenticate data routes (CSRF safety)
  r = await api("GET", "/api/summary", { headers: { cookie } });
  eq(r.status, 401, "cookie alone can't read data");

  r = await api("POST", "/api/auth/login", { body: { email: "alice@example.com", password: "wrongwrong" } });
  eq(r.status, 401, "wrong password 401");
  eq(r.data.message, "That email and password don't match.", "login error message");
  r = await api("POST", "/api/auth/login", { body: { email: "ghost@example.com", password: "whatever12" } });
  eq(r.data.message, "That email and password don't match.", "unknown email same message");
  r = await api("POST", "/api/auth/login", { body: { email: "ALICE@example.com", password: "password123" } });
  eq(r.status, 200, "login ok (case-insensitive email)");
  const aliceLoginToken = r.data.token;

  r = await api("POST", "/api/auth/logout", { token: aliceLoginToken });
  r = await api("GET", "/api/summary", { token: aliceLoginToken });
  eq(r.status, 401, "token dead after logout");

  group("auth: rate limiting");
  let got429 = false;
  for (let i = 0; i < 12; i++) {
    r = await api("POST", "/api/auth/login", { body: { email: "victim@example.com", password: "guess" + i } });
    if (r.status === 429) got429 = true;
  }
  ok(got429, "repeated bad logins get 429");

  /* ============================ BUDGET BASICS ============================ */
  group("budget: defaults, paycheck split, summary");
  const A = alice.token;
  r = await api("GET", "/api/buckets", { token: A });
  eq(r.data.map((b) => [b.name, b.percent, b.kind]), [["Bills", 50, "spending"], ["Savings", 20, "savings"], ["Personal", 10, "spending"], ["Emergency fund", 10, "savings"]], "default buckets");
  const [bills, savings, personal, emergency] = r.data;

  r = await api("GET", "/api/summary", { token: A });
  eq(r.data.savedTotal, 0, "empty saved total");
  eq(r.data.monthly.length, 6, "six months of chart data");
  eq(r.data.totalAllocatedPercent, 90, "defaults total 90% (10% stays unassigned)");

  r = await api("POST", "/api/incomes", { token: A, body: { source: "Paycheck", amount: 2100, date: TODAY, isPaycheck: true } });
  eq(r.status, 201, "income created");
  const paycheckId = r.data.id;
  r = await api("GET", "/api/summary", { token: A });
  const byName = Object.fromEntries(r.data.buckets.map((b) => [b.name, b]));
  near(byName.Bills.balance, 1050, "Bills got 50%");
  near(byName.Savings.balance, 420, "Savings got 20%");
  near(byName.Personal.balance, 210, "Personal got 10%");
  near(r.data.savedTotal, 630, "saved total = savings + emergency");
  near(r.data.unassigned, 210, "10% of the paycheck stays unassigned");
  near(r.data.monthIncome, 2100, "month income");
  near(r.data.monthly[5].saved, 630, "chart 'saved' for this month");

  r = await api("POST", "/api/expenses", { token: A, body: { description: "Groceries", amount: 82.35, category: "Groceries", date: TODAY, bucketId: personal.id } });
  eq(r.status, 201, "expense created");
  const expId = r.data.id;
  await api("POST", "/api/expenses", { token: A, body: { description: "Coffee", amount: 4.5, category: "Dining", date: TODAY, bucketId: null } });
  r = await api("GET", "/api/summary", { token: A });
  near(r.data.buckets.find((b) => b.name === "Personal").balance, 210 - 82.35, "expense reduces its bucket");
  near(r.data.unassigned, 210 - 4.5, "unassigned expense reduces unassigned");
  eq(r.data.byCategory[0].category, "Groceries", "byCategory sorted desc");
  near(r.data.monthExpenses, 86.85, "month expenses");

  group("budget: validation");
  r = await api("POST", "/api/expenses", { token: A, body: { description: "x", amount: -5, category: "Other", date: TODAY } });
  eq(r.status, 400, "negative amount rejected");
  r = await api("POST", "/api/expenses", { token: A, body: { description: "x", amount: 5, category: "Other", date: "2026-13-45" } });
  eq(r.status, 400, "bad date rejected");
  r = await api("POST", "/api/expenses", { token: A, body: { description: "x", amount: 5, category: "Other", date: TODAY, bucketId: 99999 } });
  eq(r.status, 400, "foreign bucket rejected");
  r = await api("POST", "/api/incomes", { token: A, body: { source: "x", amount: 0, date: TODAY } });
  eq(r.status, 400, "zero income rejected");
  r = await api("POST", "/api/expenses", { token: A, body: { description: "Odd", amount: 3, category: "NotACategory", date: TODAY } });
  eq(r.data.category, "Other", "unknown category → Other");

  group("budget: past splits stay put, deletes behave");
  r = await api("PATCH", `/api/buckets/${bills.id}`, { token: A, body: { name: "Bills", percent: 40, kind: "spending", goal: null, startingBalance: 100 } });
  eq(r.status, 200, "bucket patched");
  r = await api("GET", "/api/summary", { token: A });
  near(r.data.buckets.find((b) => b.name === "Bills").balance, 1050 + 100, "old paycheck split unchanged; starting balance counted");
  near(r.data.totalAllocatedPercent, 80, "totals update");
  await api("POST", "/api/incomes", { token: A, body: { source: "Side gig", amount: 1000, date: TODAY, isPaycheck: true } });
  r = await api("GET", "/api/summary", { token: A });
  near(r.data.buckets.find((b) => b.name === "Bills").balance, 1050 + 100 + 400, "new paycheck uses new percent");
  near(r.data.unassigned, 210 - 4.5 - 3 + 200, "20% of new paycheck unassigned (plus the $3 Odd expense earlier)");

  r = await api("POST", "/api/incomes", { token: A, body: { source: "Gift", amount: 50, date: TODAY, isPaycheck: false } });
  r = await api("GET", "/api/summary", { token: A });
  near(r.data.unassigned, 210 - 4.5 - 3 + 200 + 50, "non-paycheck income stays unassigned");

  r = await api("DELETE", `/api/expenses/${expId}`, { token: A });
  eq(r.status, 200, "expense deleted");
  r = await api("DELETE", `/api/incomes/${paycheckId}`, { token: A });
  r = await api("GET", "/api/summary", { token: A });
  near(r.data.buckets.find((b) => b.name === "Savings").balance, 200, "deleting a paycheck removes its split");
  r = await api("DELETE", `/api/buckets/${emergency.id}`, { token: A });
  r = await api("GET", "/api/summary", { token: A });
  eq(r.data.buckets.length, 3, "bucket deleted");
  near(r.data.unassigned, 210 - 4.5 - 3 + 200 + 50 - 210 + 100, "deleted bucket's money returns to unassigned (and the deleted paycheck's unassigned share is gone)");

  group("budget: over 100% scales down, never overshoots");
  const over = await signup("Over Bob", "over@example.com");
  const ob = (await api("GET", "/api/buckets", { token: over.token })).data;
  await api("PATCH", `/api/buckets/${ob[0].id}`, { token: over.token, body: { percent: 80 } });
  await api("PATCH", `/api/buckets/${ob[1].id}`, { token: over.token, body: { percent: 80 } });
  await api("POST", "/api/incomes", { token: over.token, body: { source: "Pay", amount: 1000.01, date: TODAY } });
  r = await api("GET", "/api/summary", { token: over.token });
  ok(r.data.unassigned >= -0.001 && r.data.unassigned < 0.1, "unassigned ≈ 0 when over 100%", r.data.unassigned);
  const allocSum = r.data.buckets.reduce((s, b) => s + b.allocated, 0);
  ok(allocSum <= 1000.01 + 1e-9, "allocations never exceed the paycheck", allocSum);

  group("free plan limits");
  const free = await signup("Free Fran", "fran@example.com");
  r = await api("POST", "/api/buckets", { token: free.token, body: { name: "Fifth", percent: 0, kind: "spending", goal: null, startingBalance: 0, color: "5" } });
  eq(r.status, 403, "free can't add a 5th bucket");
  const fb = (await api("GET", "/api/buckets", { token: free.token })).data;
  r = await api("PATCH", `/api/buckets/${fb[1].id}`, { token: free.token, body: { goal: 5000 } });
  eq(r.data.goal, null, "free users can't set goals");

  group("data isolation between users");
  r = await api("GET", "/api/expenses", { token: free.token });
  eq(r.data.length, 0, "other user's expenses not visible");
  r = await api("PATCH", `/api/buckets/${bills.id}`, { token: free.token, body: { name: "Hacked" } });
  eq(r.status, 404, "can't edit someone else's bucket");
  r = await api("DELETE", `/api/incomes/${paycheckId}`, { token: free.token });
  eq(r.status, 404, "can't delete someone else's income");
  const aliceExpenses = (await api("GET", "/api/expenses", { token: A })).data;
  r = await api("POST", "/api/expenses", { token: free.token, body: { description: "sneaky", amount: 1, category: "Other", date: TODAY, bucketId: bills.id } });
  eq(r.status, 400, "can't attach expense to someone else's bucket");

  group("sample data & reset");
  r = await api("POST", "/api/sample", { token: free.token });
  eq(r.status, 200, "sample loaded");
  r = await api("GET", "/api/summary", { token: free.token });
  ok(r.data.monthIncome >= 0, "sample summary works");
  ok(r.data.monthly.filter((m) => m.income > 0).length >= 2, "sample covers several months", r.data.monthly);
  ok((await api("GET", "/api/incomes", { token: free.token })).data.length >= 4, "sample added incomes");
  r = await api("POST", "/api/reset", { token: free.token });
  r = await api("GET", "/api/summary", { token: free.token });
  eq([r.data.buckets.length, r.data.totalIncome, r.data.monthExpenses], [4, 0, 0], "reset restores defaults and clears data");

  /* =============================== PRO GATES ============================== */
  group("pro gating");
  r = await api("POST", "/api/chat", { token: free.token, body: { message: "hi" } });
  eq(r.status, 403, "chat blocked on free");
  r = await api("POST", "/api/insight", { token: free.token });
  eq(r.status, 403, "insight blocked on free");
  r = await api("GET", "/api/bank/items", { token: free.token });
  eq(r.status, 403, "bank blocked on free");
  r = await api("GET", "/api/admin/users", { token: free.token });
  eq(r.status, 403, "admin blocked for normal users");

  /* ================================= ADMIN ================================= */
  group("admin");
  const boss = await signup("The Boss", "boss@tally.test");
  eq([boss.user.isAdmin, boss.user.plan], [true, "pro"], "admin email → admin + pro");
  r = await api("GET", "/api/admin/users", { token: boss.token });
  eq(r.status, 200, "admin can list");
  ok(r.data.stats.totalUsers >= 4, "stats count users", r.data.stats);
  ok(r.data.users.some((u) => u.email === "boss@tally.test" && u.isAdmin), "admin flagged in list");
  ok(!JSON.stringify(r.data).includes("password"), "no password data leaked");
  r = await api("PATCH", `/api/admin/users/${free.user.id}`, { token: boss.token, body: { plan: "pro" } });
  eq(r.status, 200, "admin upgrades user");
  r = await api("GET", "/api/auth/me", { token: free.token });
  eq(r.data.user.plan, "pro", "user sees Pro");
  r = await api("PATCH", `/api/admin/users/${boss.user.id}`, { token: boss.token, body: { plan: "free" } });
  eq(r.status, 400, "can't downgrade an admin");
  r = await api("PATCH", `/api/admin/users/${free.user.id}`, { token: boss.token, body: { plan: "weird" } });
  eq(r.status, 400, "bad plan rejected");

  /* ================================= PENNY ================================= */
  group("penny (chat with tools)");
  const P = free.token; // upgraded above
  r = await api("GET", "/api/messages", { token: P });
  eq(r.data, [], "no messages yet");
  r = await api("POST", "/api/chat", { token: P, body: { message: "I spent $14.50 on lunch" } });
  eq(r.status, 200, "chat ok");
  ok(/Lunch/.test(r.data.message.content), "assistant reply returned", r.data);
  eq(r.data.actions, ["Logged expense: Lunch · $14.50"], "action reported");
  ok(typeof r.data.message.id === "number", "message has id");
  ok(state.anthropicCalls.at(-1).headers["x-api-key"] === "sk-test", "api key sent");
  ok(state.anthropicCalls[0].body.system.includes("BUDGET SNAPSHOT"), "snapshot included in prompt");
  r = await api("GET", "/api/expenses", { token: P });
  eq(r.data[0].description, "Lunch", "Penny really logged the expense");
  eq(r.data[0].amount, 14.5, "…with the right amount");

  r = await api("POST", "/api/chat", { token: P, body: { message: "I just got paid $2,100" } });
  eq(r.data.actions, ["Logged paycheck: Paycheck · $2,100.00"], "paycheck action");
  r = await api("GET", "/api/summary", { token: P });
  near(r.data.monthIncome, 2100, "Penny's paycheck counted");
  near(r.data.savedTotal, 630, "…and split into buckets");

  r = await api("POST", "/api/chat", { token: P, body: { message: "make me a new bucket for vacation" } });
  eq(r.data.actions, ["Created bucket: Vacation · 5%"], "bucket created by Penny");
  r = await api("GET", "/api/buckets", { token: P });
  const vac = r.data.find((b) => b.name === "Vacation");
  eq([vac?.percent, vac?.goal, vac?.kind], [5, 1500, "savings"], "bucket has the right fields (Pro can set goals)");

  r = await api("POST", "/api/chat", { token: P, body: { message: "delete the ghost bucket" } });
  eq(r.data.actions, [], "failed tool → no action claimed");
  ok(/didn't work/.test(r.data.message.content), "failure surfaced to the person", r.data.message.content);

  r = await api("GET", "/api/messages", { token: P });
  eq(r.data.length, 8, "all turns persisted");
  eq(r.data.map((m) => m.role).slice(0, 2), ["user", "assistant"], "roles alternate");
  r = await api("POST", "/api/insight", { token: P });
  ok(/dining/.test(r.data.text), "insight returns text", r.data);
  r = await api("POST", "/api/chat", { token: P, body: { message: "   " } });
  eq(r.status, 400, "blank message rejected");
  // another user can't see Penny history
  r = await api("GET", "/api/messages", { token: boss.token });
  eq(r.data, [], "messages are private");
  r = await api("DELETE", "/api/messages", { token: P });
  r = await api("GET", "/api/messages", { token: P });
  eq(r.data, [], "clear chat works");

  /* ================================ BILLING ================================ */
  group("billing (Stripe)");
  const payer = await signup("Pat Payer", "pat@example.com");
  r = await api("GET", "/api/billing/config", { token: payer.token });
  eq(r.data, { enabled: true }, "billing enabled");
  r = await api("POST", "/api/billing/checkout", { token: payer.token, body: { interval: "year", returnUrl: `${base}/#/billing` } });
  eq(r.data.url, "https://checkout.stripe.test/c/cs_1", "checkout url returned");
  const sess = state.stripeCalls.find((c) => c.url === "/v1/checkout/sessions");
  const sp = new URLSearchParams(sess.body);
  eq(sp.get("mode"), "subscription", "subscription mode");
  eq(sp.get("line_items[0][price_data][unit_amount]"), "7999", "yearly price $79.99");
  eq(sp.get("line_items[0][price_data][recurring][interval]"), "year", "yearly interval");
  eq(sp.get("success_url"), `${base}/#/billing`, "returns to our site");
  eq(sess.auth, "Bearer sk_test_123", "stripe auth header");
  await api("POST", "/api/billing/checkout", { token: payer.token, body: { interval: "month", returnUrl: "https://evil.example/steal" } });
  const sess2 = new URLSearchParams(state.stripeCalls.filter((c) => c.url === "/v1/checkout/sessions").at(-1).body);
  eq(sess2.get("line_items[0][price_data][unit_amount]"), "1199", "monthly price $11.99");
  ok(!sess2.get("success_url").includes("evil.example"), "open-redirect blocked", sess2.get("success_url"));
  eq(state.stripeCalls.filter((c) => c.url === "/v1/customers").length, 1, "customer created once");

  r = await api("POST", "/api/billing/sync", { token: payer.token });
  eq(r.data.user.plan, "free", "no subscription yet → free");
  const periodEnd = Math.floor(Date.now() / 1000) + 30 * 86400;
  state.stripeSubs = [{ status: "active", items: { data: [{ price: { recurring: { interval: "year" } }, current_period_end: periodEnd }] } }];
  r = await api("POST", "/api/billing/sync", { token: payer.token });
  eq([r.data.user.plan, r.data.user.planInterval], ["pro", "year"], "active sub → pro/yearly");
  ok(Math.abs(Date.parse(r.data.user.planRenewsAt) / 1000 - periodEnd) < 2, "renewal date set");

  // webhook
  const sign = (payload, secret = "whsec_test", t = Math.floor(Date.now() / 1000)) =>
    `t=${t},v1=${crypto.createHmac("sha256", secret).update(`${t}.${payload}`).digest("hex")}`;
  const evt = JSON.stringify({ type: "customer.subscription.deleted", data: { object: { customer: "cus_test_1", status: "canceled" } } });
  r = await api("POST", "/api/billing/webhook", { raw: evt, headers: { "content-type": "application/json", "stripe-signature": sign(evt, "wrong") } });
  eq(r.status, 400, "bad webhook signature rejected");
  r = await api("POST", "/api/billing/webhook", { raw: evt, headers: { "content-type": "application/json", "stripe-signature": sign(evt) } });
  eq(r.status, 200, "good webhook accepted");
  r = await api("GET", "/api/auth/me", { token: payer.token });
  eq(r.data.user.plan, "free", "cancel webhook → back to free");
  const evt2 = JSON.stringify({ type: "customer.subscription.updated", data: { object: { customer: "cus_test_1", status: "active", items: { data: [{ price: { recurring: { interval: "month" } }, current_period_end: periodEnd }] } } } });
  await api("POST", "/api/billing/webhook", { raw: evt2, headers: { "content-type": "application/json", "stripe-signature": sign(evt2) } });
  r = await api("GET", "/api/auth/me", { token: payer.token });
  eq([r.data.user.plan, r.data.user.planInterval], ["pro", "month"], "update webhook → pro/monthly");
  r = await api("POST", "/api/billing/portal", { token: payer.token, body: { returnUrl: base } });
  eq(r.data.url, "https://billing.stripe.test/p/1", "portal url");
  r = await api("POST", "/api/billing/portal");
  eq(r.status, 401, "portal needs auth");
  // revenue stat
  r = await api("GET", "/api/admin/users", { token: boss.token });
  near(r.data.stats.mrr, 11.99, "admin MRR counts Stripe subscribers only");
  // manual comp survives a sync
  const comp = payer; // has stripe customer; mark manual via admin
  await api("PATCH", `/api/admin/users/${comp.user.id}`, { token: boss.token, body: { plan: "pro" } });
  state.stripeSubs = [];
  r = await api("POST", "/api/billing/sync", { token: comp.token });
  eq(r.data.user.plan, "pro", "admin-granted Pro isn't revoked by sync");

  /* ================================== BANK ================================== */
  group("bank (Plaid)");
  const banker = await signup("Bea Banker", "bea@example.com");
  await api("PATCH", `/api/admin/users/${banker.user.id}`, { token: boss.token, body: { plan: "pro" } });
  const BT = banker.token;
  r = await api("GET", "/api/bank/config", { token: BT });
  eq(r.data, { enabled: true, env: "sandbox" }, "bank config");
  r = await api("POST", "/api/bank/link-token", { token: BT });
  eq(r.data, { linkToken: "link-sandbox-abc" }, "link token");
  const ltCall = state.plaidCalls.find((c) => c.url === "/link/token/create");
  eq([ltCall.body.client_id, ltCall.body.products], ["cid", ["transactions"]], "link token request shaped right");
  r = await api("POST", "/api/bank/exchange", { token: BT, body: { publicToken: "public-sandbox-1", institution: "First Platypus Bank" } });
  eq(r.data.institution, "First Platypus Bank", "exchange ok");
  eq(r.data.added, 3, "imported 2 expenses + 1 income, skipped transfer & pending");
  r = await api("GET", "/api/expenses", { token: BT });
  const descs = r.data.map((e) => e.description).sort();
  eq(descs, ["Blue Bottle", "TRADER JOES"], "expenses imported with merchant names");
  eq(r.data.find((e) => e.description === "TRADER JOES").category, "Groceries", "category mapped");
  eq(r.data.find((e) => e.description === "Blue Bottle").category, "Dining", "category mapped (coffee → dining)");
  r = await api("GET", "/api/incomes", { token: BT });
  eq([r.data[0].source, r.data[0].amount, r.data[0].isPaycheck], ["ACME PAYROLL", 2400, true], "payroll imported as split paycheck");
  r = await api("GET", "/api/bank/items", { token: BT });
  eq([r.data.length, r.data[0].imported], [1, 3], "item listed with imported count");
  ok(!JSON.stringify(r.data).includes("access"), "access token never sent to browser");
  const rawRow = JSON.stringify(Object.values(await (async () => (await import("../server/db.js")).db.prepare("SELECT access_token_enc FROM bank_items").get())()));
  ok(!rawRow.includes("access-sandbox-xyz"), "access token encrypted at rest");
  r = await api("POST", "/api/bank/sync", { token: BT });
  eq(r.data.added, 0, "re-sync adds nothing new (dedupe)");
  r = await api("GET", "/api/expenses", { token: BT });
  eq(r.data.length, 1, "Plaid 'removed' deleted the matching entry");
  r = await api("DELETE", `/api/bank/items/1`, { token: BT });
  eq(r.status, 200, "bank disconnected");
  r = await api("GET", "/api/incomes", { token: BT });
  eq(r.data.length, 1, "imported entries stay after disconnect");
  r = await api("DELETE", `/api/bank/items/1`, { token: BT });
  eq(r.status, 404, "double-disconnect is 404");

  /* ================================ DELETE USER ================================ */
  group("admin delete user cascades");
  r = await api("DELETE", `/api/admin/users/${boss.user.id}`, { token: boss.token });
  eq(r.status, 400, "can't delete self");
  r = await api("DELETE", `/api/admin/users/${over.user.id}`, { token: boss.token });
  eq(r.status, 200, "admin deleted a user");
  r = await api("GET", "/api/summary", { token: over.token });
  eq(r.status, 401, "deleted user's session is dead");
  const { db } = await import("../server/db.js");
  eq(db.prepare("SELECT COUNT(*) c FROM buckets WHERE user_id=?").get(over.user.id).c, 0, "their data is gone");

  /* ================================== STATIC ================================== */
  group("static site");
  r = await api("GET", "/");
  ok(typeof r.data === "string" && r.data.includes('<div id="root">'), "serves the app shell");
  ok(!r.data.includes("pplx"), "no leftover Perplexity script");
  const js = await api("GET", "/assets/index-CSn-blOk.js");
  ok(js.status === 200 && !js.data.includes("port/5000"), "bundle served, host-specific base URL removed");
  r = await api("GET", "/plan");
  ok(r.data.includes('<div id="root">'), "unknown paths fall back to the app");
  r = await api("GET", "/api/nope", { token: A });
  eq(r.status, 404, "unknown API route is JSON 404");
  r = await api("POST", "/api/auth/login", { raw: "{not json", headers: { "content-type": "application/json" } });
  eq(r.status, 400, "malformed JSON → 400, not a crash");
  r = await api("GET", "/healthz");
  eq(r.data, { ok: true }, "health check");
} catch (e) {
  failed++;
  console.log("  ✗ test crashed:", e);
} finally {
  server.close();
  mocks.close();
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
}
