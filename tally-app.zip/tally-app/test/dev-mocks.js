// Runs the real app on :5077 against fake Anthropic/Stripe/Plaid servers. For manual / browser testing only.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { startMocks } from "./mocks.js";

const mocks = await startMocks();
Object.assign(process.env, {
  DATA_DIR: fs.mkdtempSync(path.join(os.tmpdir(), "tally-dev-")),
  ADMIN_EMAIL: "owner@tally.test",
  ANTHROPIC_API_KEY: "sk-test", ANTHROPIC_BASE_URL: mocks.anthropic.url,
  STRIPE_SECRET_KEY: "sk_test", STRIPE_BASE_URL: mocks.stripe.url,
  PLAID_CLIENT_ID: "x", PLAID_SECRET: "y", PLAID_BASE_URL: mocks.plaid.url,
});
const { app } = await import("../server/index.js");
app.listen(5077, () => console.log("dev on 5077"));
