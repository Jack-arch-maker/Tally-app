// Tiny fake versions of Anthropic, Stripe and Plaid so the whole app can be tested offline.
import http from "node:http";

function server(handler) {
  return new Promise((resolve) => {
    const s = http.createServer((req, res) => {
      let body = "";
      req.on("data", (c) => (body += c));
      req.on("end", () => handler(req, res, body));
    });
    s.listen(0, "127.0.0.1", () => resolve({ s, url: `http://127.0.0.1:${s.address().port}` }));
  });
}
const json = (res, obj, status = 200) => {
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(obj));
};

export const state = {
  anthropicCalls: [],
  stripeCalls: [],
  stripeSubs: [],
  plaidCalls: [],
};

export async function startMocks() {
  const anthropic = await server((req, res, body) => {
    const b = JSON.parse(body);
    state.anthropicCalls.push({ headers: req.headers, body: b });
    const last = b.messages[b.messages.length - 1];
    const text = typeof last.content === "string" ? last.content : "";
    const tool = (name, input) =>
      json(res, { stop_reason: "tool_use", content: [{ type: "text", text: "On it." }, { type: "tool_use", id: "tu_" + name, name, input }] });
    if (Array.isArray(last.content) && last.content[0]?.type === "tool_result") {
      const failed = last.content[0].is_error;
      return json(res, { stop_reason: "end_turn", content: [{ type: "text", text: failed ? "That didn't work: " + last.content[0].content : "All done — " + last.content[0].content }] });
    }
    if (!b.tools) return json(res, { stop_reason: "end_turn", content: [{ type: "text", text: "You're spending a bit more on dining. Try a $50 weekly cap." }] });
    if (/spent \$14\.50/.test(text)) return tool("log_expense", { description: "Lunch", amount: 14.5, category: "Dining" });
    if (/paid \$2,100/.test(text)) return tool("log_income", { source: "Paycheck", amount: 2100 });
    if (/new bucket/.test(text)) return tool("save_bucket", { name: "Vacation", percent: 5, kind: "savings", goal: 1500 });
    if (/ghost bucket/.test(text)) return tool("delete_bucket", { name: "Ghost" });
    return json(res, { stop_reason: "end_turn", content: [{ type: "text", text: "You're doing fine: system had " + (b.system.includes("BUDGET SNAPSHOT") ? "snapshot" : "no snapshot") }] });
  });

  const stripe = await server((req, res, body) => {
    state.stripeCalls.push({ method: req.method, url: req.url, body, auth: req.headers.authorization });
    if (req.method === "POST" && req.url === "/v1/customers") return json(res, { id: "cus_test_1" });
    if (req.method === "POST" && req.url === "/v1/checkout/sessions") return json(res, { id: "cs_1", url: "https://checkout.stripe.test/c/cs_1" });
    if (req.method === "POST" && req.url === "/v1/billing_portal/sessions") return json(res, { url: "https://billing.stripe.test/p/1" });
    if (req.method === "GET" && req.url.startsWith("/v1/subscriptions")) return json(res, { data: state.stripeSubs });
    json(res, { error: { message: "unexpected " + req.method + " " + req.url } }, 400);
  });

  const plaid = await server((req, res, body) => {
    const b = JSON.parse(body || "{}");
    state.plaidCalls.push({ url: req.url, body: b });
    if (req.url === "/link/token/create") return json(res, { link_token: "link-sandbox-abc" });
    if (req.url === "/item/public_token/exchange") return json(res, { access_token: "access-sandbox-xyz", item_id: "item_1" });
    if (req.url === "/item/remove") return json(res, { removed: true });
    if (req.url === "/transactions/sync") {
      if (b.cursor === "c1") return json(res, { added: [], modified: [], removed: [{ transaction_id: "t2" }], next_cursor: "c2", has_more: false });
      if (b.cursor === "c2") return json(res, { added: [], modified: [], removed: [], next_cursor: "c2", has_more: false });
      return json(res, {
        added: [
          { transaction_id: "t1", amount: 12.4, date: "2026-10-30", name: "BLUE BOTTLE", merchant_name: "Blue Bottle", pending: false, personal_finance_category: { primary: "FOOD_AND_DRINK", detailed: "FOOD_AND_DRINK_COFFEE" } },
          { transaction_id: "t2", amount: 55.1, date: "2026-10-31", name: "TRADER JOES", pending: false, personal_finance_category: { primary: "FOOD_AND_DRINK", detailed: "FOOD_AND_DRINK_GROCERIES" } },
          { transaction_id: "t3", amount: -2400, date: "2026-10-31", name: "ACME PAYROLL", pending: false, personal_finance_category: { primary: "INCOME", detailed: "INCOME_WAGES" } },
          { transaction_id: "t4", amount: 500, date: "2026-10-31", name: "Transfer to savings", pending: false, personal_finance_category: { primary: "TRANSFER_OUT", detailed: "TRANSFER_OUT_SAVINGS" } },
          { transaction_id: "t5", amount: 9.99, date: "2026-11-01", name: "Pending thing", pending: true },
        ],
        modified: [], removed: [], next_cursor: "c1", has_more: false,
      });
    }
    json(res, { error_code: "NOPE", error_message: "unexpected " + req.url }, 400);
  });

  return { anthropic, stripe, plaid, close: () => [anthropic, stripe, plaid].forEach((m) => m.s.close()) };
}
